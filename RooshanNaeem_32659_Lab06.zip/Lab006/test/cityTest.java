/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author roosh
 */
public class cityTest {
    
    public cityTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    /*public void rightCity() throws SQLException{
    String exp = "Cairo";
    String city="";
    Scanner in = new Scanner(System.in);
                 try{Class.forName("com.mysql.jdbc.Driver");}catch(ClassNotFoundException e){}
                 Connection con = DriverManager.getConnection("jdbc:mysql://localhost/citylite?"
              + "user=root&password=roosh");
                System.out.print("\nEnter a Id of City you want to search: \n");
                int id = in.nextInt();
                PreparedStatement stm = con.prepareStatement("Select city,latitude,longitude from cities where locId =?");
                stm.setInt(1, id);
                 ResultSet rs = stm.executeQuery();
                 while(rs.next()){
                 city = rs.getString("city");
                 System.out.print(city);
    }
                 if(exp == city){
                 System.out.print("Passed");
                 }
                 else{
                 System.out.print("Failed");
                 }
                 
}*/
    
    public void distance(){
    Scanner s = new Scanner(System.in);
    double x1 =33.0053 , y1=-7.6183, x2=33.0053, y2=-7.6183;
    double exp = 0;
    double distance;
    final double radius = 6371.01;
  
 
  
    distance = radius * Math.acos(Math.toRadians((Math.sin(Math.toRadians(x1)) * Math.sin(Math.toRadians(x2)) + Math.cos(Math.toRadians(x1)) * Math.cos(Math.toRadians(x2)) * Math.cos(Math.toRadians(y2 - y1)))));
  
    if((exp -distance) == 0 ){
    System.out.print("Passed");
    }
    else{
        System.out.print("Failed");

    }
 
    }
   
}