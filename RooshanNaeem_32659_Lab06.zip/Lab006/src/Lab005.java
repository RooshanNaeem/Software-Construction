/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.opencsv.CSVReader;
import static java.awt.FileDialog.LOAD;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;   
import static javafx.scene.input.ScrollEvent.VerticalTextScrollUnits.LINES;
import javax.persistence.Query;
import org.hibernate.Session;  
import org.hibernate.SessionFactory;  
import org.hibernate.Transaction;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;  
import org.hibernate.service.ServiceRegistry;

/**
 *
 * @author roosh
 */


public class Lab005 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
   
    String csvFilename = "GeoLiteCity.csv";
    String nextLine;
     List<City> list = new  ArrayList <City>();
     try (BufferedReader reader = new BufferedReader(new FileReader(csvFilename))){
         reader.readLine();
         reader.readLine();
      while ((nextLine = reader.readLine()) != null) {
         
                        City c1=new City();
                        String[] records;
                        
                        records = nextLine.split(",");
                        //System.out.println(records);
                        if(records.length>8 && !records[8].equals("\"\"")&& !records[8].equals("")){  
			c1.setAreaCode(Integer.parseInt(records[8]));}
                        c1.setCountry(records[1]);
                        c1.setLocId(Integer.parseInt(records[0]));
                        c1.setCity(records[3]);
                        c1.setLatitude(Float.valueOf(records[5]));
                        c1.setLongitude(Float.valueOf(records[6]));
                        if(records.length>7 && !records[7].equals("\"\"") && !records[7].equals("")){ 
                        c1.setMetroCode(Integer.parseInt(records[7]));}
                        if(!records[4].equals("\"\"")&& !records[4].equals("")){
                        c1.setPostalCode(records[4]);}
                        c1.setRegion(records[2]);
                        list.add(c1);
                        
       }
//...
     }catch(Exception e){
        System.err.println("Error: " + e.getMessage());
    }
     
     
                Configuration cfg= new Configuration() {};  
		cfg.configure("hibernate.cfg.xml");//populates the data of the configuration file  
                
		//creating seession factory object  
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties()). build();
		SessionFactory factory=cfg.buildSessionFactory(serviceRegistry);
                
		//creating session object  
		Session session=factory.openSession(); 
                
			//creating transaction object 
                        int temp = 1;
                        int length = list.size();
                        //City c1=new City();
                        //System.out.println(length);
                        String[] records;
                       /* while(temp != length){
			Transaction t=session.beginTransaction(); 
                        //records = list.get(temp).split(",");
                        //System.out.println(records);
			  
			City c1;
                        c1 = list.get(temp);
			session.persist(c1);//persisting the object  
                        temp++;
			t.commit();//transaction is commited  
                        
                        }*/
                         
                  
                System.out.print("Inserted");
                Scanner in = new Scanner(System.in);
                System.out.print("\nEnter a Id of City-1 you want to search: \n");
                int id = in.nextInt();
                List<Float> lonn = new ArrayList <Float>();
                Iterator iter =session.createQuery("from City where locId = ?")
                .setParameter(0,id).iterate();
                //List list2;
                while(iter.hasNext()){
                City cty = (City) iter.next();
                System.out.print("City: "+cty.getCity()+"\n");
                System.out.print("Latitude: "+cty.getLatitude()+"\n");
                System.out.print("Longitude: "+cty.getLongitude());
                lonn.add(new Float(cty.getLatitude()));
                lonn.add(new Float(cty.getLongitude()));
                
                }
                System.out.println("\n"+lonn+"\n");
                System.out.print("\nEnter a Id of City-2 you want to search a distance: \n");
                int id2 = in.nextInt();
                List<Float> lonn2 = new ArrayList <Float>();
                Iterator iter2 =session.createQuery("from City where locId = ?")
                .setParameter(0,id2).iterate();
                //List list2;
                while(iter2.hasNext()){
                City cty2 = (City) iter2.next();
                System.out.print("City: "+cty2.getCity()+"\n");
                System.out.print("Latitude: "+cty2.getLatitude()+"\n");
                System.out.print("Longitude: "+cty2.getLongitude());
                lonn2.add(new Float(cty2.getLatitude()));
                lonn2.add(new Float(cty2.getLongitude()));
                
                }
                System.out.println("\n"+lonn2+"\n");
                City cty=new City();
                cty.Distance(lonn.get(0),lonn.get(1), lonn2.get(0), lonn2.get(1));
                
                session.close();
                //list2 = query.list();
                /*PreparedStatement stm = con.prepareStatement("Select city,latitude,longitude from cities where locId =?");
                stm.setInt(1, id);
                 ResultSet rs = stm.executeQuery();
                 while(rs.next()){
                 String cty = rs.getString("city");
                 String lat = rs.getString("latitude");
                 String lon = rs.getString("longitude");
                 System.out.print("City "+cty);
                 System.out.print("\nLatitude "+lat);
                 System.out.print("\nLongitude "+lon);
                 lonn.add(new Float(lat));
                 lonn.add(new Float(lon));
                    }*/
                
                 
                /* System.out.print("\n\nEnter ids of cities to locate cities nearby:\n\n");
                 System.out.print("Enter City-1:\n");
                 //int ids = in.nextInt();
                 PreparedStatement stm1 = con.prepareStatement("Select latitude,longitude from cities ");
                 //stm1.setInt(1, ids); 
                 ResultSet rs1 = stm1.executeQuery();
                 List<Float> lat = new ArrayList <Float>();
                 while(rs1.next()){
                 //String cty1 = rs1.getString("city");
                 String lat1 = rs1.getString("latitude");
                 String lon1 = rs1.getString("longitude");
                 //System.out.print("City "+cty1);
                 //System.out.print("\nLatitude "+lat1);
                 //System.out.print("\nLongitude "+lon1);
                 lat.add(new Float(lat1));
                 lat.add(new Float(lon1));
                 }
                 //System.out.print(lat.get(3));
                 City cc = new City();
                cc.distance(lonn.get(0),lonn.get(1),lat.get(0),lat.get(1));*/
                 
                
                 
               }
    
              
                

                
                
                    
                
    
       
    }

        
    