
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




/**
 *
 * @author roosh
 */
@Entity
@Table(name="city")
public class City {
    @Id 
    @Column(name="locId")
    private int locId;
    @Column(name="country")
    private String country;
    @Column(name="region")
    private String region;
    @Column(name="city")
    private String city;
    @Column(name="postalCode")
    private String postalCode;
    @Column(name="latitude")
    private float latitude;
    @Column(name="longitude")
    private float longitude;
    @Column(name="metroCode")
    private int metroCode;
    @Column(name="areaCode")
    private int areaCode;
    
    
    //public City(){};

    public int getLocId() {
        return locId;
    }

    public void setLocId(int locId) {
        this.locId = locId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public int getMetroCode() {
        return metroCode;
    }

    public void setMetroCode(int metroCode) {
        this.metroCode = metroCode;
    }

    public int getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(int areaCode) {
        this.areaCode = areaCode;
    }
    
    public void Distance(Float lon1, Float lat1, Float lon2, Float lat2){
        double dlon, dlat, a, b, c, d, e, f, g;
        dlon = lon2 - lon1;
        dlat = lat2 - lat1; 
        a = Math.pow(Math.sin(dlat/2),2);
        b = Math.cos(lat1);
        c = Math.cos(lat2);
        d = Math.pow(Math.sin(dlon/2),2);
        e = b * c * d;
        f = a + e;
        g = 2 * Math.asin(Math.sqrt(f))* 6371;
        System.out.print("The distance between two cities is: "+g+"Kms");
    }
    
 
}
