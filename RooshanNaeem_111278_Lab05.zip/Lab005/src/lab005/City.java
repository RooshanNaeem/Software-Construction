/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab005;

/**
 *
 * @author roosh
 */
public class City {
    private int id;
    private String country;
    private String region;
    private String city;
    private int postalcode;
    private int lat;
    private int lon;
    private int metrocode;
    private int areacode;
    
    
    public City(){};
    public void setid(int Id){
    id = Id;
    }
    public void setcountry(String cnt){
    country = cnt;
    }
    public void setregion(String rgn){
    region = rgn;
    }
    public void setcity(String cty){
    city = cty;
    }
    public void setpostalcode(int pos){
    postalcode = pos;
    }
    public void setlat(int lat){
    lat = lat;
    }
    public void setlon(int Lon){
    lon = Lon;
    }
    public void setmetrocode(int mcode){
    metrocode = mcode;
    }
    public void setarea(int area){
    areacode = area;
    }
    public int getId(){
    return id;
    }
    public int getlat(){
    return lat;
    }
    public int getlon(){
    return lon;
    }
    public String getcity(){
    return city;
    }
}
