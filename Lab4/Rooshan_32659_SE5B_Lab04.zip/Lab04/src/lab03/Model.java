/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

/**
 *
 * @author roosh
 */
public class Model {
        String user;
        String pass;
        
        public Model(String name, String pas){
        this.user = name;
        this.pass = pas;
        
        }
        
}
