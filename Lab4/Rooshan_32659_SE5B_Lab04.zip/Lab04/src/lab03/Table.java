/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

/**
 *
 * @author roosh
 */
public abstract class Table {
    int capacity;
    int availabletables;
    String size;
    
}

class Extra_Large extends Table{

    public Extra_Large(){
    
        this.capacity = 12;
        this.availabletables = 1;
        this.size = "Extra";
    
    
    
    }

}
class Large extends Table{

    public Large(){
    
        this.capacity = 6;
        this.availabletables = 3;
        this.size = "Large";
    
    
    
    }

}
class Medium extends Table{

    public Medium(){
    
        this.capacity = 4;
        this.availabletables = 8;
        this.size = "Medium";
    
    
    
    }

}
class Small extends Table{

    public Small(){
    
        this.capacity = 2;
        this.availabletables = 4;
        this.size = "Small";
    
    
    
    }

}