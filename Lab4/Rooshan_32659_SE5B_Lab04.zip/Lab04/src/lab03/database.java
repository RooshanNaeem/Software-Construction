/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author roosh
 */
public class database {
   public void connection(){
   try {
            String host = "jdbc:derby://localhost:1527/Restaurant";
            String uName = "";
            String uPass = "";
            Connection con = (Connection) DriverManager.getConnection(host, uName, uPass);
        } catch (SQLException err) {
            System.out.println(err.getMessage());
        }
       
   
   }
}
