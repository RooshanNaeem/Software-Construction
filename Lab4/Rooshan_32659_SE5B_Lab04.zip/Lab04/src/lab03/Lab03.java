/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

/**
 *
 * @author roosh
 */
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Lab03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here,
        System.out.print("Welcome to our Online Reservation System\n\n");
        
        System.out.print("Enter User name\n");
        Scanner sc = new Scanner(System.in);
        String name;
        name = sc.next();
         
        try {
            
            String host = "jdbc:derby://localhost:1527/Restaurant";
            String uName = "";
            String uPass = "";
            Connection con = (Connection) DriverManager.getConnection(host, uName, uPass);
            Statement st = con.createStatement();
            
            String query = "SELECT username from customer where username ='"+name+"'  ";
            ResultSet res = st.executeQuery(query);
            
            if(!res.next()){
                System.out.print("Not verified user");
            }
            
        } catch (SQLException err) {
            System.out.println(err.getMessage());
        }
         Model model = new Model("Rooshan", "shan");
        Priorty priorty = new Priorty();
        FormingTables tabb = new FormingTables();
       
        
        
        
        
       Order o = new Order(model.user,"Dinner", 12, 8,priorty,tabb);
       Order o2 = new Order("Bilal","Lunch",6,10,priorty,tabb);
       FormingTables table = new FormingTables();
       table.table("Extra");
       table.table("Small");
      
       Restaurant r = new Restaurant(o, table,priorty);
       Restaurant r2 = new Restaurant(o2,table,priorty);
       r.booking();
       r2.booking();
   
   }
    
      
    }
    

