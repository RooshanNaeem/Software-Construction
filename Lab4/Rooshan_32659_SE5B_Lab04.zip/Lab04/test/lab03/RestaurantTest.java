/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author roosh
 */
public class RestaurantTest {
    
    public RestaurantTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of booking method, of class Restaurant.
     */
    @Test
    public void testBooking() {
        System.out.println("booking");
        Restaurant instance = null;
        instance.booking();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    @Test
    public void testorder(){
    FormingTables table = new FormingTables();
    Priorty p = new Priorty();
    
    Order o = new Order("Rooshan", "Dinner",4,3,p,table);
    Restaurant r = new Restaurant(o,table,p);
    
    r.booking();
    int res = 3;
    int mem = o.members;
    
    assertEquals(res,mem);
    
    
    }
}
