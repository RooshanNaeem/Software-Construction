/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author roosh
 */
public class Test1 {
    @Test
    
    public void checkMul(){
    
    int a [][] = {{1,2},{3,4}};
    int b[][] = {{1,2},{3,4}};
    
    int r [][];
    
    Matrix mul = new Matrix(2,2,2,2,a,b);
    
    r = m.iterativeMul();
    
    if(r == null){
    fail("Can not multiply the matrices");
    
    }
    
    }
    
    @Test
    public void multest(){
    int a[][] = {{1,2},{3,4}};
    int b [][] = {{4,3},{2,1}};
    
    int res[][];
    
    Matrix m2 = new Matrix(2,2,2,2,a,b);
    
    res= m2.iterativeMul();
    
    int ans[][] = {{8,5},{20,13}};
    
    for(int j=0;j<2;j++){
        for(int k=0;k<2;k+){
            if(res[j][k] != ans[j][k]){
            
            fail("Test did not pass");
            }
        }
    }
            
    
    
    }
    
}
