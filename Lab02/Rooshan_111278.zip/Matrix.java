/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author roosh
 */
public class Matrix {
     int m;
    int n;
    
    int i;
    int j;
    
   
    
    int first[][];
    int second[][];
    
    Matrix(int row1, int col1, int row2, int col2, int frst[][], int sec[][] ){
    
    this.m = row1;
    this.n = col1;
    this.i = row2;
    this.j = col2;
    
   first = frst;
   second = sec;
    }
    public int[][] iterativeMul(){
    
    int mul[][] = new int [m][j];
    
    if(n != i){
    return null;
    
    }
    else{
    
     int sum=0;
    
    for ( int x = 0 ; x < m ; x++ )
         {
            for ( int y = 0 ; y < j ; y++ )
            {   
               for ( int k = 0 ; k < i ; k++ )
               {
                  sum = sum + first[x][k] * second[k][y];
               }
 
               mul[x][y] = sum;
               sum = 0;
            }
         }
                 return mul;
    }
    
    
    
    }
    
}
