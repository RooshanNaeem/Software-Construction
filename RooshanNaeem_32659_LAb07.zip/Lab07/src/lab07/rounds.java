/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07;

import java.util.List;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author roosh
 */
@Entity
@Table(name ="Rounds")
public class rounds{
    @Id
    @Column(name="RoundId")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int roundId;
    @Column(name="USERID")
    private String userId;
    @Column(name="SCHEME")
    private String scheme;
    @Column(name="TimeTaken")
    private float time;
    @Column(name="State")
    private String state;
    @Column(name="challengeId")
    private List<challenges> Challenge;

    public int getRoundId() {
        return roundId;
    }

    public void setRoundId(int roundId) {
        this.roundId = roundId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public float getTime() {
        return time;
    }

    public void setTime(float time) {
        this.time = time;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<challenges> getChallenge() {
        return Challenge;
    }

    public void setChallenge(List<challenges> Challenge) {
        this.Challenge = Challenge;
    }
    
    
    

    
    
}
