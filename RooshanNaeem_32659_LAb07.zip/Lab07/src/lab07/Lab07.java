/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab07;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author roosh
 */
public class Lab07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String filename = "csvfile.csv";
        String nextLine;
     List<rounds> list = new  ArrayList <rounds>();
     List<challenges> list1 = new ArrayList <challenges>();
     try (BufferedReader reader = new BufferedReader(new FileReader(filename))){
         reader.readLine();
         reader.readLine();
         reader.readLine();
      while ((nextLine = reader.readLine()) != null) {
         
                        rounds r1=new rounds();
                        challenges c1 = new challenges(); 
                        String[] records;
                        
                        records = nextLine.split(",");
                        //System.out.println(records);
                        if(records.length>8 && !records[8].equals("\"\"")&& !records[8].equals("")){  
			r1.setUserId(records[0]);}
                        r1.setScheme(records[2]);
                        if(records.length>8 && !records[8].equals("\"\"")&& !records[8].equals("")){
                        r1.setTime(Float.valueOf(records[3]));}
                        r1.setState(records[4]);
                        if(records.length>8 && !records[8].equals("\"\"")&& !records[8].equals("")){
                        c1.setTime(Float.valueOf(records[6]));}
                        c1.setState(records[7]);
                      /*if(records.length>7 && !records[7].equals("\"\"") && !records[7].equals("")){ 
                        c1.setMetroCode(Integer.parseInt(records[7]));}
                        if(!records[4].equals("\"\"")&& !records[4].equals("")){
                        c1.setPostalCode(records[4]);}
                        c1.setRegion(records[2]);
                        list.add(c1);*/
                        
       }
//...
                        }catch(Exception e){
                        System.err.println("Error: " + e.getMessage());
                     }
    }
    
}
