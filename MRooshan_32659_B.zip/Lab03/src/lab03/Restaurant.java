/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

/**
 *
 * @author roosh
 */
public class Restaurant {
    
    FormingTables table;
    Order order;
    Priorty p;
    public Restaurant(Order o,FormingTables t,Priorty pr){
    
    this.order = o;
    this.table = t;
    this.p = pr;
    
    }
    public void booking(){
        if(table.table.size == "Extra"){
        
        if(table.table.availabletables > 0){
            if(order.priorty >= p.get_highest()){
        
        System.out.print("Exttra Large table has been booked for "+order.members+" members\n");
        System.out.print("Total Items are "+order.items+" total\n");
        System.out.print("Total waiting time is"+order.waiting+"mins, Thanks\n");
        
        
        }
            table.table.availabletables --;
        }
        }
        else 
            if(table.table.size == "Large"){
            if(table.table.availabletables > 0){
            
            System.out.print("Large table has been booked for "+order.members+" members\n");
            System.out.print("Total Items are "+order.items+" total\n");
            System.out.print("Total waiting time is"+order.waiting+"mins, Thanks\n");
            }
            table.table.availabletables --;
            }
        else 
            if(table.table.size == "Medium"){
            if(table.table.availabletables > 0){
            
            System.out.print("Medium table has been booked for "+order.members+" members\n");
            System.out.print("Total Items are "+order.items+" total\n");
            System.out.print("Total waiting time is"+order.waiting+"mins, Thanks\n");
            }
            table.table.availabletables --;
            }
        else 
            if(table.table.size == "Small"){
            if(table.table.availabletables > 0){
            
            System.out.print("Small table has been booked for "+order.members+" members\n");
            System.out.print("Total Items are "+order.items+" total\n");
            System.out.print("Total waiting time is"+order.waiting+"mins, Thanks\n");
            }
            table.table.availabletables --;
            }
    
    
    
    }
}
