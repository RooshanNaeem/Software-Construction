/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

/**
 *
 * @author roosh
 */
public class Lab03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here,
        Priorty priorty = new Priorty();
       Order o = new Order("Rooshan", "Dinner", 12, 8,priorty);
       FormingTables table = new FormingTables();
       table.table("Extra");
       table.table("Small");
       Restaurant r = new Restaurant(o, table,priorty);
       r.booking();
    }
    
}
