/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab03;

/**
 *
 * @author roosh
 */
import java.util.ArrayList;
import java.util.List;
public class Order {
    
    String name;
    String type;
    int items;
    int max;
    int priorty;
    int members;
    int waiting;
    Priorty p;
    List<Integer> orderlist = new ArrayList();
    
    public Order(String nm,String tp,int item,int mem, Priorty pr){
    
    this.name = nm;
    this.items = item;
    this.type = tp;
    this.max = 25;
    this.members = mem;
    this.p = pr;
    this.waiting = (this.members)*5;
    orderPriorty();
    this.orderlist.add(getPriorty());
    pr.queue(orderlist);
    
    }
    
    public void orderPriorty(){
    
    if(members > 10){
    
    priorty = 5;
    }
    if(members >= 8 && members <10 ){
    priorty = 4;
    }
    if(members >= 6 && members <8 ){
    priorty = 3;
    }
    if(members >= 4 && members <6 ){
    priorty = 2;
    }
    if(members >= 2 && members <4 ){
    priorty = 1;
    }
    }
    public int getPriorty(){
    return priorty;
    }
}
